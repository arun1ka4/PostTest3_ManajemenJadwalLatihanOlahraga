package Main;

import Service.MenuJadwal;
import java.util.Scanner;

public class ManajemenJadwalLatihan {
    public static void main(String[] args) {
        MenuJadwal menu = new MenuJadwal();
        Scanner input = new Scanner(System.in);
        String pilih;

        do {
            System.out.println("\n=== JADWAL LATIHAN OLAHRAGA ===");
            System.out.println("1. Tambah Jadwal");
            System.out.println("2. Lihat Jadwal");
            System.out.println("3. Update Jadwal");
            System.out.println("4. Hapus Jadwal");
            System.out.println("5. Cari Jadwal berdasarkan Hari");
            System.out.println("6. Keluar");
            System.out.print("Pilih menu: ");
            pilih = input.nextLine().trim();

            switch (pilih) {
                case "1":
                    menu.tambahJadwal();
                    break;
                case "2":
                    menu.lihatJadwal();
                    break;
                case "3":
                    menu.updateJadwal();
                    break;
                case "4":
                    menu.hapusJadwal();
                    break;
                case "5":
                    menu.cariJadwalHari();
                    break;
                case "6":
                    System.out.println("Terima kasih telah menggunakan program.");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
            }
        } while (!pilih.equals("6"));

        input.close();
    }
}
