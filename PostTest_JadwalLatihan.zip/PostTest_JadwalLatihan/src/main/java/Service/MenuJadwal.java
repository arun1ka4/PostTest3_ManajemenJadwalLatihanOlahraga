package Service;

import Model.*;
import java.util.ArrayList;
import java.util.Scanner;

public class MenuJadwal {
    private ArrayList<JadwalLatihan> daftarJadwal = new ArrayList<>();
    private Scanner input = new Scanner(System.in);

    public void tambahJadwal() {
        System.out.print("Masukkan Hari: ");
        String hari = input.nextLine().trim();

        System.out.print("Masukkan Jenis Latihan: ");
        String jenis = input.nextLine().trim();

        System.out.print("Masukkan Waktu (HH:MM): ");
        String waktu = input.nextLine().trim();

        String kategori = "";
        while(true) {
            System.out.println("Pilih kategori latihan:");
            System.out.println("1. Kardio");
            System.out.println("2. Kekuatan");
            System.out.println("3. Tidak ada");
            System.out.print("Kategori: ");
            String pilih = input.nextLine().trim();

            if(pilih.equals("1")) {
                kategori = "Kardio";
                break;
            } else if(pilih.equals("2")) {
                kategori = "Kekuatan";
                break;
            } else if(pilih.equals("3")) {
                kategori = "-";
                break;
            } else {
                System.out.println("Pilihan tidak valid, silakan coba lagi.");
            }
        }

        if(hari.isEmpty() || jenis.isEmpty() || waktu.isEmpty()) {
            System.out.println("Input tidak valid, jadwal gagal ditambahkan!");
            return;
        }

        JadwalLatihan jadwal;
        if(kategori.equals("Kardio")) {
            System.out.print("Masukkan durasi (menit): ");
            if (input.hasNextDouble()) {
                double durasi = input.nextDouble();
                input.nextLine();
                System.out.print("Masukkan jarak (km): ");
                if (input.hasNextDouble()) {
                    double jarak = input.nextDouble();
                    input.nextLine();
                    jadwal = new Kardio(hari, jenis, waktu, kategori, durasi, jarak);
                } else {
                    System.out.println("Input harus berupa angka.");
                    input.nextLine();
                    return;
                }
            } else {
                System.out.println("Input harus berupa angka.");
                input.nextLine();
                return;
            }
        } else if(kategori.equals("Kekuatan")) {
            System.out.print("Masukkan jumlah set: ");
            if (input.hasNextInt()) {
                int set = input.nextInt();
                System.out.print("Masukkan jumlah repetisi per set: ");
                if (input.hasNextInt()) {
                    int rep = input.nextInt();
                    input.nextLine();
                    jadwal = new Kekuatan(hari, jenis, waktu, kategori, set, rep);
                } else {
                    System.out.println("Input harus berupa angka bilangan bulat.");
                    input.nextLine();
                    return;
                }
            } else {
                System.out.println("Input harus berupa angka bilangan bulat.");
                input.nextLine();
                return;
            }
        } else {
            jadwal = new JadwalLatihan(hari, jenis, waktu, kategori);
        }

        daftarJadwal.add(jadwal);
        System.out.println("Jadwal berhasil ditambahkan.");
    }

    public void lihatJadwal() {
        if(daftarJadwal.isEmpty()) {
            System.out.println("Belum ada jadwal latihan.");
            return;
        }
        System.out.println("== Daftar Jadwal Latihan ==");
        for(int i=0; i<daftarJadwal.size(); i++) {
            System.out.println((i+1)+".");
            daftarJadwal.get(i).tampilkanInfo();
            System.out.println("----------------------------");
        }
    }

    public void updateJadwal() {
        lihatJadwal();
        if (daftarJadwal.isEmpty()) return;

        System.out.print("Masukkan nomor jadwal yang ingin diperbarui: ");
        int index = input.nextInt();
        input.nextLine();

        if(index <= 0 || index > daftarJadwal.size()) {
            System.out.println("Nomor tidak valid.");
            return;
        }

        System.out.print("Masukkan Hari baru: ");
        String hari = input.nextLine().trim();

        System.out.print("Masukkan Jenis Latihan baru: ");
        String jenis = input.nextLine().trim();

        System.out.print("Masukkan Waktu baru (HH:MM): ");
        String waktu = input.nextLine().trim();

        String kategori = "";
        while(true) {
            System.out.println("Pilih kategori latihan baru:");
            System.out.println("1. Kardio");
            System.out.println("2. Kekuatan");
            System.out.println("3. Tidak ada");
            System.out.print("Kategori: ");
            String pilih = input.nextLine().trim();

            if(pilih.equals("1")) {
                kategori = "Kardio";
                break;
            } else if(pilih.equals("2")) {
                kategori = "Kekuatan";
                break;
            } else if(pilih.equals("3")) {
                kategori = "-";
                break;
            } else {
                System.out.println("Pilihan tidak valid, silakan coba lagi.");
            }
        }

        if(hari.isEmpty() || jenis.isEmpty() || waktu.isEmpty()) {
            System.out.println("Input tidak valid, update gagal!");
            return;
        }

        JadwalLatihan jadwal;
        if(kategori.equals("Kardio")) {
            System.out.print("Masukkan durasi (menit): ");
            if (input.hasNextDouble()) {
                double durasi = input.nextDouble();
                input.nextLine();
                System.out.print("Masukkan jarak (km): ");
                if (input.hasNextDouble()) {
                    double jarak = input.nextDouble();
                    input.nextLine();
                    jadwal = new Kardio(hari, jenis, waktu, kategori, durasi, jarak);
                } else {
                    System.out.println("Input harus berupa angka.");
                    input.nextLine();
                    return;
                }
            } else {
                System.out.println("Input harus berupa angka.");
                input.nextLine();
                return;
            }
        } else if(kategori.equals("Kekuatan")) {
            System.out.print("Masukkan jumlah set: ");
            if (input.hasNextInt()) {
                int set = input.nextInt();
                input.nextLine();
                System.out.print("Masukkan jumlah repetisi per set: ");
                if (input.hasNextInt()) {
                    int rep = input.nextInt();
                    input.nextLine();
                    jadwal = new Kekuatan(hari, jenis, waktu, kategori, set, rep);
                } else {
                    System.out.println("Input harus berupa angka bilangan bulat.");
                    input.nextLine();
                    return;
                }
            } else {
                System.out.println("Input harus berupa angka bilangan bulat.");
                input.nextLine();
                return;
            }
        } else {
            jadwal = new JadwalLatihan(hari, jenis, waktu, kategori);
        }

        daftarJadwal.set(index-1, jadwal);
        System.out.println("Jadwal berhasil diperbarui.");
    }

    public void hapusJadwal() {
        lihatJadwal();
        if(daftarJadwal.isEmpty()) return;

        System.out.print("Masukkan nomor jadwal yang ingin dihapus: ");
        int index = input.nextInt();
        input.nextLine();

        if(index>0 && index<=daftarJadwal.size()) {
            daftarJadwal.remove(index-1);
            System.out.println("Jadwal berhasil dihapus.");
        } else {
            System.out.println("Nomor tidak valid.");
        }
    }

    public void cariJadwalHari() {
        System.out.print("Masukkan hari yang ingin dicari: ");
        String cariHari = input.nextLine().trim();

        boolean ditemukan = false;
        for(JadwalLatihan j : daftarJadwal) {
            if(j.getHari().equalsIgnoreCase(cariHari)) {
                j.tampilkanInfo();
                System.out.println("----------------------------");
                ditemukan = true;
            }
        }

        if(!ditemukan) {
            System.out.println("Tidak ada jadwal latihan di hari " + cariHari);
        }
    }
}
