package Model;
public class Kardio extends JadwalLatihan{
    private double durasi;
    private double jarak;
    
    public Kardio(String hari, String jenisLatihan, String waktu, String kategori, double durasi, double jarak){
        super(hari, jenisLatihan, waktu, kategori);
        this.durasi = durasi;
        this.jarak = jarak;
    }

    public double getDurasi() {
        return durasi;
    }

    public void setDurasi(double durasi) {
        this.durasi = durasi;
    }

    public double getJarak() {
        return jarak;
    }

    public void setJarak(double jarak) {
        this.jarak = jarak;
    }
    
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Durasi      : " + this.durasi);
        System.out.println("Jarak(km)   : " + this.jarak);
        
    }
}
