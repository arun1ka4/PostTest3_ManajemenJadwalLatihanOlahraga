package Model;
public class Kekuatan extends JadwalLatihan{
    private int jumlahSet;
    private int jumlahRepetisi;
    
    public Kekuatan(String hari, String jenisLatihan, String waktu, String kategori, int jumlahSet, int jumlahRepetisi) {
        super(hari, jenisLatihan, waktu, kategori);
        this.jumlahSet = jumlahSet;
        this.jumlahRepetisi = jumlahRepetisi;
    }

    public int getJumlahSet() {
        return jumlahSet;
    }

    public void setJumlahSet(int jumlahSet) {
        this.jumlahSet = jumlahSet;
    }

    public int getJumlahRepetisi() {
        return jumlahRepetisi;
    }

    public void setJumlahRepetisi(int jumlahRepetisi) {
        this.jumlahRepetisi = jumlahRepetisi;
    }
    
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Set x Rep   :" + this.jumlahSet + " x " + this.jumlahRepetisi);
    }
}
