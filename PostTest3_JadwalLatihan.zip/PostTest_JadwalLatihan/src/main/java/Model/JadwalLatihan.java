package Model;

public class JadwalLatihan {
    private String hari;
    private String jenisLatihan;
    private String waktu;
    private String kategori;

    public JadwalLatihan(String hari, String jenisLatihan, String waktu, String kategori) {
        this.hari = hari;
        this.jenisLatihan = jenisLatihan;
        this.waktu = waktu;
        this.kategori = kategori;
    }

    public String getHari() {
        return hari;
    }

    public void setHari(String hari) {
        this.hari = hari;
    }

    public String getJenisLatihan() {
        return jenisLatihan;
    }

    public void setJenisLatihan(String jenisLatihan) {
        this.jenisLatihan = jenisLatihan;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }
    
    public void tampilkanInfo() {
        System.out.println("Hari        : " + this.hari);
        System.out.println("Nama Latihan: " + this.jenisLatihan);
        System.out.println("Waktu       : " + this.waktu);
        System.out.println("Kategori    : " + this.kategori);
    }
//
//    @Override
//    public String toString() {
//        return hari + " - " + jenisLatihan + " | " + waktu;
//    }
}
