package Model;
public class Kardio extends JadwalLatihan{
    private int durasi;
    private double jarak;
    
    public Kardio(String hari, String jenisLatihan, String waktu,String kategori, int durasi, double jarak){
        super(hari, jenisLatihan, waktu, kategori);
        this.durasi = durasi;
        this.jarak = jarak;
    }

    public int getDurasi() {
        return durasi;
    }

    public void setDurasi(int durasi) {
        this.durasi = durasi;
    }

    public double getJarak() {
        return jarak;
    }

    public void setJarak(double jarak) {
        this.jarak = jarak;
    }
    
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Durasi      : " + this.durasi);
        System.out.println("Jarak(km)   : " + this.jarak);
        
    }
}
